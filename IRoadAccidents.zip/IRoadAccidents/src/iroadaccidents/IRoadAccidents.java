

package iroadaccidents;

import java.util.Scanner;

// Title: Road Accident Report Generation
// Author: Adapted from "Java Programming: A Comprehensive Guide" by Herbert Schildt
// Date: September 30, 2024
// Version: 1


//This interface defines methods to access information about a road accident report.
interface IRoadAccidents {
    //Gets the type of vehicle involved in the accident.
    String getAccidentVehicleType();
    String getCity();
    int getAccidentTotal();
}
//class provides a base implementation for road accidents reports
abstract class RoadAccidents implements IRoadAccidents {
    private String vehicleType;
    private String city;
    private int accidentTotal;

    public RoadAccidents(String vehicleType, String city, int accidentTotal) {
        this.vehicleType = vehicleType;
        this.city = city;
        this.accidentTotal = accidentTotal;
    }

    public String getAccidentVehicleType() {
        return vehicleType;
    }

    public String getCity() {
        return city;
    }

    public int getAccidentTotal() {
        return accidentTotal;
    }
}


class RoadAccidentReport extends RoadAccidents {
    public RoadAccidentReport(String vehicleType, String city, int accidentTotal) {
        super(vehicleType, city, accidentTotal);
    }
//Prints the details of the road accident report to the console.
    public void printAccidentReport() {
        System.out.println("\nVEHICLE ACCIDENT REPORT");
        System.out.println("VEHICLE TYPE: " + getAccidentVehicleType());
        System.out.println("CITY: " + getCity());
        System.out.println("ACCIDENT TOTAL: " + getAccidentTotal());
    }
}

//This class is the entry point for the application
//It prompts the user for input, creates a RoadAccidentReport object,
//and prints the report details.
class RunApplication {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the accident vehicle type: ");
        String vehicleType = scanner.nextLine();

        System.out.print("Enter the city for the vehicle accidents: ");
        String city = scanner.nextLine();

        System.out.print("Enter the total " + vehicleType + " accidents for " + city + ": ");
        int accidentTotal = scanner.nextInt();

        RoadAccidentReport report = new RoadAccidentReport(vehicleType, city, accidentTotal);
        report.printAccidentReport();
    }
}
