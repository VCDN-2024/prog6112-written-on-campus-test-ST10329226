/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package roadaccidents;

import java.util.Scanner;

public class RoadAccidents {

    public static void main(String[] args) {
        // Input data from the image
        int[][] accidentCounts = {
                {155, 121}, // Cape Town
                {178, 145}, // Johannesburg
                {112, 89}  // Port Elizabeth
        };

        String[] cities = {"Cape Town", "Johannesburg", "Port Elizabeth"};

        // Get user input
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a city (Cape Town, Johannesburg, or Port Elizabeth): ");
        String inputCity = scanner.nextLine();
        System.out.print("Enter a vehicle type (car or bike): ");
        String inputVehicle = scanner.nextLine();

        // Find the index of the city
        int cityIndex = -1;
        for (int i = 0; i < cities.length; i++) {
            if (cities[i].equalsIgnoreCase(inputCity)) {
                cityIndex = i;
                break;
            }
        }

        // Check if the city was found and display the result
        if (cityIndex != -1) {
            int accidentCount = 0;
            if (inputVehicle.equalsIgnoreCase("car")) {
                accidentCount = accidentCounts[cityIndex][0];
            } else if (inputVehicle.equalsIgnoreCase("bike")) {
                accidentCount = accidentCounts[cityIndex][1];
            } else {
                System.out.println("Invalid vehicle type. Please enter 'car' or 'bike'.");
                return;
            }

            System.out.println("Number of " + inputVehicle + " accidents in " + inputCity + ": " + accidentCount);
        } else {
            System.out.println("Invalid city. Please enter 'Cape Town', 'Johannesburg', or 'Port Elizabeth'.");
        }
    }
}